﻿using project.fil.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project.fil.Classes
{
    internal class AppData
    {
        public static authEntities db = new authEntities();
    }
}
